#include "point.h"


Point::Point(int xCor, int yCor) :
    x{ xCor }, y{ yCor }
{}


Point::~Point()
{
}
