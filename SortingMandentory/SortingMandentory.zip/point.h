#pragma once
class Point
{
public:
    Point(int x, int y);
    int x;
    int y;
    double slope;
    ~Point();

private:

};

